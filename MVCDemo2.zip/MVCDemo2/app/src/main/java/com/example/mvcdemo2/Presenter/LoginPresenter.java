package com.example.mvcdemo2.Presenter;

import com.example.mvcdemo2.Model.User;
import com.example.mvcdemo2.View.ILoginView;

public class LoginPresenter implements ILoginPresenter
{
    ILoginView loginView;

    public LoginPresenter(ILoginView loginView) {
        this.loginView = loginView;
    }

    @Override
    public void onLogin(String email, String password) {
        User user = new User(email,password);
        boolean isLoginSuccess = user.isValidData();

        if(isLoginSuccess)
            loginView.onLoginResult("Login Successfully");
        else
            loginView.onLoginResult("Login Error!!!!");
    }
}
