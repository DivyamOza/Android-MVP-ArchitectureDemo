package com.example.mvcdemo2.View;

public interface ILoginView
{
    void onLoginResult(String message);
}
