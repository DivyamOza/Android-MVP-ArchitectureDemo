package com.example.mvcdemo2.Presenter;

public interface ILoginPresenter
{
    void onLogin(String email,String password);
}
