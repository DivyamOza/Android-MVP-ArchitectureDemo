package com.example.mvcdemo2.Model;

public interface IUser
{
    String getEmail();
    String getPassword();
    boolean isValidData();
}
